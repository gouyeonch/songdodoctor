<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>송도연세정형외과의원</title>
<meta name="description" content="송도 위치, 척추, 관절, 비수술치료, 도수치료, 재활, 교정, 신경치료, 성장발달">
<meta property="og:title" content="송도연세정형외과의원"/>
<meta property="og:type" content="website"/>
<meta property="og:url" content="http://songdos.com/"/>
<meta property="og:site_name" content="송도연세정형외과의원"/>
<meta property="og:description" content="송도 위치, 척추, 관절, 비수술치료, 도수치료, 재활, 교정, 신경치료, 성장발달"/>
<meta name="naver-site-verification" content="88008ec688ad09d62eff1dbcb2d7576c8a57e630"/>

<link href="/css/reset.css" rel="stylesheet" type="text/css" />
<link href="/css/index.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="/css/colorbox.css" />
<link rel="stylesheet" href="/css/common.css" media="screen" title="no title">

<script src="http://code.jquery.com/jquery-1.12.3.min.js"></script>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<script src="/js/jquery.colorbox.js"></script>
<script src="/js/common.js"></script>

	<script type="text/javascript">

		//nav 글씨 변화-------------------------------------------------------------------------------//
		// $(document).ready(
		// 	function(){
		// 		var a=0;
		// 		$("nav ul li a:eq(0)").hover(
		// 			function(){
		// 				if(a==0){
		// 					$("nav ul li a:eq(0)").text("척추질환");
		// 					a=1;
		// 				}
		// 				else{
		// 					$("nav ul li a:eq(0)").text("준비중");
		// 					$("nav ul li a:eq(1)").text("관절질환");
		// 					$("nav ul li a:eq(2)").text("통증질환");
		// 					$("nav ul li a:eq(3)").text("최단진단기기");
		// 					$("nav ul li a:eq(4)").text("비수술치료법");
		// 					$("nav ul li a:eq(5)").text("첨단치료기기");
		// 					a=0;
		// 				}
		// 			}
		// 		);
		// 		$("nav ul li a:eq(1)").hover(
		// 			function(){
		// 				if(a==0){
		// 					$("nav ul li a:eq(1)").text("관절질환");
		// 					a=1;
		// 				}
		// 				else{
		// 					$("nav ul li a:eq(0)").text("척추질환");
		// 					$("nav ul li a:eq(1)").text("준비중");
		// 					$("nav ul li a:eq(2)").text("통증질환");
		// 					$("nav ul li a:eq(3)").text("최단진단기기");
		// 					$("nav ul li a:eq(4)").text("비수술치료법");
		// 					$("nav ul li a:eq(5)").text("첨단치료기기");
		// 					a=0;
		// 				}
		// 			}
		// 		);
		// 		$("nav ul li a:eq(2)").hover(
		// 			function(){
		// 				if(a==0){
		// 					$("nav ul li a:eq(2)").text("통증질환");
		// 					a=1;
		// 				}
		// 				else{
		// 					$("nav ul li a:eq(0)").text("척추질환");
		// 					$("nav ul li a:eq(1)").text("관절질환");
		// 					$("nav ul li a:eq(2)").text("준비중");
		// 					$("nav ul li a:eq(3)").text("최단진단기기");
		// 					$("nav ul li a:eq(4)").text("비수술치료법");
		// 					$("nav ul li a:eq(5)").text("첨단치료기기");
		// 					a=0;
		// 				}
		// 			}
		// 		);
		// 		$("nav ul li a:eq(3)").hover(
		// 			function(){
		// 				if(a==0){
		// 					$("nav ul li a:eq(3)").text("최단진단기기");
		// 					a=1;
		// 				}
		// 				else{
		// 					$("nav ul li a:eq(0)").text("척추질환");
		// 					$("nav ul li a:eq(1)").text("관절질환");
		// 					$("nav ul li a:eq(2)").text("통증질환");
		// 					$("nav ul li a:eq(3)").text("준비중");
		// 					$("nav ul li a:eq(4)").text("비수술치료법");
		// 					$("nav ul li a:eq(5)").text("첨단치료기기");
		// 					a=0;
		// 				}
		// 			}
		// 		);
		// 		$("nav ul li a:eq(4)").hover(
		// 			function(){
		// 				if(a==0){
		// 					$("nav ul li a:eq(4)").text("비수술치료법");
		// 					a=1;
		// 				}
		// 				else{
		// 					$("nav ul li a:eq(0)").text("척추질환");
		// 					$("nav ul li a:eq(1)").text("관절질환");
		// 					$("nav ul li a:eq(2)").text("통증질환");
		// 					$("nav ul li a:eq(3)").text("최단진단기기");
		// 					$("nav ul li a:eq(4)").text("준비중");
		// 					$("nav ul li a:eq(5)").text("첨단치료기기");
		// 					a=0;
		// 				}
		// 			}
		// 		);
		// 		$("nav ul li a:eq(5)").hover(
		// 			function(){
		// 				if(a==0){
		// 					$("nav ul li a:eq(5)").text("첨단치료기기");
		// 					a=1;
		// 				}
		// 				else{
		// 					$("nav ul li a:eq(0)").text("척추질환");
		// 					$("nav ul li a:eq(1)").text("관절질환");
		// 					$("nav ul li a:eq(2)").text("통증질환");
		// 					$("nav ul li a:eq(3)").text("최단진단기기");
		// 					$("nav ul li a:eq(4)").text("비수술치료법");
		// 					$("nav ul li a:eq(5)").text("준비중");
		// 					a=0;
		// 				}
		// 			}
		// 		);
		// 	}
		// );

		//구글 지도 팝업-------------------------------------------------------------------------------//
		function newPop(url, w, h){
			window.open(url,"","width="+w+",height="+h+",scrollbars=yes");
		}

		$(document).ready(function(){

			//color box-------------------------------------------------------------------------------//
			$(".group1").colorbox({rel:'group1'});
			$("#click").click(function(){
			$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit",}).text("Open this window again and this message will still be here.");
			return false;
			});

			

			//오른쪽 그림 애니메이션-------------------------------------------------------------------------------//
			var smb=0;
			$(".bg3 .smb").click(function(){
				if($(".bg3").hasClass("smclose")){
					$(".bg3 .smb img").hide();
					$(".bg3").addClass("smclose");
					$(this).css("background","url('/img/hoverclose.png') 20px 0px no-repeat");
					smb=1;
					$('.bg3').css('right','0').removeClass("smclose");
				}
				else{
					$(".bg3 .smb img").hide();
					$(".bg3").removeClass("smclose");
					$(this).css("background","url('/img/hover.png') no-repeat");
					smb=0;
					$('.bg3').css('right','-210px').addClass("smclose");
				}
			});
		});

	</script>
  </head>
  <style media="screen">
  .title{background: url('/method/img/method_main_img.jpg')no-repeat;background-size:cover;}
  .menu_logo{background: url('/method/img/method_logo.png')no-repeat 1px 0;}
  .contents>img{margin: 35px 0 20px;text-align: left;display: block;}
  footer{background:#f8f8f8; }

  </style>  

  <body>
    <!--ㅡnav--------------------------------------------------------------------------->
<header>
  <nav>
      <h1><a href="http://songdos.com/index.html"><img src="/img/menulogo.png" alt=""></a></h1>
        <ul>
          <li><a href="/intro/introduce.php"><h2>병원소개</h2></a></li>
            <li><a href="/device/device01.php"><h2>진단기기</h2></a></li>
            <li><a href="/method/method01_01.php"><h2>치료방법</h2></a></li>
            <li><a href="/therapy/therapy01.php"><h2>도수치료/체형교정</h2></a></li>
        </ul>
    </nav>
</header>
    <div class="title">
      <div class="max_wid">
        <div class="menu_logo"></div><!--
        --><h1>치료방법</h1>
      </div>
    </div>

    <div id="wrap">
      <div class="menu_left_wrap">
        <!-- 왼쪽메뉴 -->
        <div class="menu_left">
          <ul>
            <li>
				<a href="method01_01.php">척추 비수술 치료</a>
				<ul class="dep2" style="display:none;">
					<li><a href="method01_02.php">신경성형술</a></li>
					<li><a href="method01_03.php">신경차단술</a></li>
				</ul>
			</li>
            <li><a href="method02.php">관절/인대 비수술치료</a></li>
            <li>
			    <a href="method03.php">특수 통증치료</a></li>
                <li class="on">
			       <ul class="dep2">
					<li><a href="method03_02.php" class="on">ESWT</a></li>
				   </ul>
		    <li><a href="method04.php">pgo gait</a></li>
          </ul>
        </div><!--
      --><div class="contents">
           <p style="padding-top:40px;"><img src="/method/img/img_method03.png" alt="특수 통증치료" /></p>
      </div>

    </div>
  </body>
  <!-- 오른쪽메뉴 -->
<div class="bg3">
  <div class="smb">
      <img src="/img/hoverclose.png" alt="">
    </div>
  <div class="reservation">
      <h3>대표전화</h3>
        <div class="info">
          <h4 style="border:0;">032.832.5488</h4>
<h3>도수치료센터</h3>
<h4 style="font-size: 24px;">070.4456.4366</h4>
            <p class="date">
              월 - 금 am9:00-pm7:00<br>
              (물리치료 pm8시까지)<br>
              점&nbsp;&nbsp;&nbsp;&nbsp;심 pm1:00-pm2:00<br>
              토요일 am9:00-pm2:00
            </p>
            <p class="exp">
              토요일은 점심시간 없이 오후 2시까지 운영합니다.<br>
            </p>
        </div>
        <div class="look">
          <div class="look1">
              <a class="group1" href="/intro/img/introduce_img_popup.png">
                    <h5><img src="/img/doctorlogo.png"></h5>
                    <p>의료진소개</p>
                </a>
            </div>
            <div class="look2">
              <a href="#" class="group2">
                    <h5><img src="/img/hospitallogo.png"></h5>
                    <p>병원둘러보기</p>
                </a>
            </div>
            <div class="look3">
              <a href="http://me2.do/5vovoxSY" onclick="newPop(this.href,1000,1000);return false;" >
                    <h5><img src="/img/maplogo.png"></h5>
                    <p>오시는길</p>
                </a>
            </div>
        </div>
        <!--<div class="naver">
          <a href="#">
              <h4><img src="img/naverlogo.png" alt=""></h3>
              <p>네이버블로그</p>
            </a>
        </div>-->
        <h6><img src="/img/boctors.png" alt=""></h6>
    </div>
</div>
</div>
</div>
<style type="text/css">
#mask {  
  position:absolute;  
  z-index:50;  
  background-color:#000;  
  display:none;  
  left:0;
  top:0;
}
.window{
  display: none;
  position:absolute;  
  left:100px;
  top:100px;
  z-index:10000;
}
</style>
	<script type="text/javascript">
	function wrapWindowByMask(){
	var maskHeight = $(document).height();  
	var maskWidth = $(window).width();  

	$('#mask').css({'width':maskWidth,'height':maskHeight});  

	//애니메이션 효과 - 일단 1초동안 까맣게 됐다가 80% 불투명도로 간다.
	$('#mask').fadeIn(1000);      
	$('#mask').fadeTo("slow",0.8);    

	$('.window').show();
}

$(document).ready(function(){
	//검은 막 띄우기
	$('.look2 .group2').click(function(e){
		e.preventDefault();
		wrapWindowByMask();
		$('#slideshow').show();  
		$('#layClose').show();  
	});

	//닫기 버튼을 눌렀을 때
	$('#layClose').click(function (e) {  
		//링크 기본동작은 작동하지 않도록 한다.
		e.preventDefault();  
		$('#mask, .window').hide();  
		$('#slideshow').hide();  
		$('#layClose').hide();  
	});       

	//검은 막을 눌렀을 때
	$('#mask').click(function () {  
		$(this).hide();  
		$('.window').hide();  
	});      
});
</script>  <!--ㅡfooter--------------------------------------------------------------------------->
       	<footer>
        	<div class="bottom" style="position:relative;">
                <h2><img src="/img/bottomlogo.png" alt=""></h2>
                <ul>
                    <li>원장:김기학<span>|</span></li>
					<li>사업자 등록번호:122-35-32181<span>|</span></li>
                    <li>주소:인천광역시 연수구 송도동 22-2번지<span>|</span></li>
                    <li>대표전화:032-832-5488<span>|</span></li>
                    <li>팩스번호:032-832-9199</li>
                </ul>
                <p style="position:absolute;bottom:2px;left:40px;">Copyright © 송도연세정형외과의원. All rights reserved.</p>
            </div>
        </footer>
</html>
